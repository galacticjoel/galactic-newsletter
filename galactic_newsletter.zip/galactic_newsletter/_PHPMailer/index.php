<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP; //Load Composer's autoloader (created by composer, not included with PHPMailer)

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

require 'vendor/autoload.php';

error_reporting(E_ALL);

date_default_timezone_set('Etc/UTC');

$host = 'localhost';
$db   = 'newsletter';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "Connected successfully";
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}

$stmt = $pdo->query("SELECT COL1 FROM portal");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
var_dump($users);

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'galacticjoel3@gmail.com';                     //SMTP username
    $mail->Password   = 'ilcw layu qqea xgao';                               //SMTP password
    //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 	      //Enable implicit TLS encryption
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
    $mail->Port       = 587;                                    //465 TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('joel9754@yandex.com', 'MEDITATION');
    //$mail->addAddress('joe@example.net', 'Joe User');     //Add a recipient
    $mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('joel9754@yandex.com');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


// //Passing `true` enables PHPMailer exceptions
// $mail = new PHPMailer(true);

// $body = file_get_contents('contents.html');

// $mail->isSMTP();
// $mail->Host = 'smtp.example.com';
// $mail->SMTPAuth = true;
// $mail->SMTPKeepAlive = true; //SMTP connection will not close after each email sent, reduces SMTP overhead
// $mail->Port = 25;
// $mail->Username = 'yourname@example.com';
// $mail->Password = 'yourpassword';
// $mail->setFrom('list@example.com', 'List manager');
// $mail->addReplyTo('list@example.com', 'List manager');
// $mail->addCustomHeader(
    // 'List-Unsubscribe',
    // '<mailto:unsubscribes@example.com>, <https://www.example.com/unsubscribe.php>'
// );
// $mail->Subject = 'PHPMailer Simple database mailing list test';

// //Same body for all messages, so set this before the sending loop
// //If you generate a different body for each recipient (e.g. you're using a templating system),
// //set it inside the loop
// $mail->msgHTML($body);
// //msgHTML also sets AltBody, but if you want a custom one, set it afterwards
// $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';

// //Connect to the database and select the recipients from your mailing list that have not yet been sent to
// //You'll need to alter this to match your database
// $mysql = mysqli_connect('localhost', 'username', 'password');
// mysqli_select_db($mysql, 'mydb');
// $result = mysqli_query($mysql, 'SELECT full_name, email, photo FROM mailinglist WHERE sent = FALSE');

// foreach ($result as $row) {
    // try {
        // $mail->addAddress($row['email'], $row['full_name']);
    // } catch (Exception $e) {
        // printf(
            // 'Invalid address skipped: %s<br>',
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401)
        // );
        // continue;
    // }
    // if (!empty($row['photo'])) {
        // //Assumes the image data is stored in the DB
        // $mail->addStringAttachment($row['photo'], 'YourPhoto.jpg');
    // }
    // $mail->replaceCustomHeader(
        // 'List-Unsubscribe',
        // '<mailto:unsubscribes@example.com>, <https://www.example.com/unsubscribe.php?email=' .
        // rawurlencode($row['email']) . '>'
    // );

    // try {
        // $mail->send();
        // printf(
            // 'Message sent to : %s (%s)<br>',
            // htmlspecialchars($row['full_name'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401)
        // );
        // //Mark it as sent in the DB
        // mysqli_query(
            // $mysql,
            // "UPDATE mailinglist SET sent = TRUE WHERE email = '" .
            // mysqli_real_escape_string($mysql, $row['email']) . "'"
        // );
    // } catch (Exception $e) {
        // printf(
            // 'Mailer Error (%s) %s<br>',
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
            // $mail->ErrorInfo
        // );
        // //Reset the connection to abort sending this message
        // //The loop will continue trying to send to the rest of the list
        // $mail->getSMTPInstance()->reset();
    // }
    // //Clear all addresses and attachments for the next iteration
    // $mail->clearAddresses();
    // $mail->clearAttachments();
	
	
	
	
// $mail = new PHPMailer(true);
// $mail->isSMTP();
// // ... SMTP configuration ...

// foreach ($recipients as $email => $name) {
    // $mail->addAddress($email, $name);
    // $mail->Subject = 'Subject';
    // $mail->Body = 'Body content';
    
    // if (!$mail->send()) {
        // echo "Error sending to $email";
    // }
    
    // // Reset for next recipient
    // $mail->clearAddresses();
    // $mail->clearAttachments();
// }
// Method 3: Single Email to Multiple Recipients To send the same email to multiple users without them seeing each other, add all addresses to one instance and use addBCC() or set
 // $mail->SingleTo = true to send individual SMTP transactions while keeping recipients private. 

// $mail = new PHPMailer();
// $mail->isSMTP();
// $mail->Host = 'smtp.example.com';
// $mail->setFrom('from@example.com', 'Sender Name');
// $mail->addAddress('to@example.com', 'Recipient Name'); // Wymagane
// $mail->addBCC('bcc1@example.com', 'Bcc Name 1');
// $mail->addBCC('bcc2@example.com', 'Bcc Name 2');
// $mail->Subject = 'Test';
// $mail->Body = 'Body';
// $mail->send();

$sth = null;
$dbh = null;