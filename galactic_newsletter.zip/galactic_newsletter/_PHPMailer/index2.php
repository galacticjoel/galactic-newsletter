<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP; //Load Composer's autoloader (created by composer, not included with PHPMailer)

require './src/Exception.php';
require './src/PHPMailer.php';
require './src/SMTP.php';

require 'vendor/autoload.php';

error_reporting(E_ALL);

date_default_timezone_set('Etc/UTC');

$host = 'localhost';
$db   = 'newsletter';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "Connected successfully";
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}

$stmt = $pdo->query("SELECT COL1 FROM portal");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
var_dump($users);

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'galacticjoel3@gmail.com';                     //SMTP username
    $mail->Password   = 'ilcw layu qqea xgao';                               //SMTP password
    //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 	      //Enable implicit TLS encryption
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
    $mail->Port       = 587;                                    //465 TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('joel9754@yandex.com', 'MEDITATION');
    $mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('joel9754@yandex.com');
 

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'Nowy wpis od Cobry';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}



//Same body for all messages, so set this before the sending loop


// foreach ($result as $row) {
    // try {
        // $mail->addAddress($row['email'], $row['full_name']);
    // } catch (Exception $e) {
        // printf(
            // 'Invalid address skipped: %s<br>',
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401)
        // );
        // continue;
    // }
    // if (!empty($row['photo'])) {
        // //Assumes the image data is stored in the DB
        // $mail->addStringAttachment($row['photo'], 'YourPhoto.jpg');
    // }
    // $mail->replaceCustomHeader(
        // 'List-Unsubscribe',
        // '<mailto:unsubscribes@example.com>, <https://www.example.com/unsubscribe.php?email=' .
        // rawurlencode($row['email']) . '>'
    // );

    // try {
        // $mail->send();
        // printf(
            // 'Message sent to : %s (%s)<br>',
            // htmlspecialchars($row['full_name'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401)
        // );
        // //Mark it as sent in the DB
        // mysqli_query(
            // $mysql,
            // "UPDATE mailinglist SET sent = TRUE WHERE email = '" .
            // mysqli_real_escape_string($mysql, $row['email']) . "'"
        // );
    // } catch (Exception $e) {
        // printf(
            // 'Mailer Error (%s) %s<br>',
            // htmlspecialchars($row['email'], ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401),
            // $mail->ErrorInfo
        // );
        // //Reset the connection to abort sending this message
        // //The loop will continue trying to send to the rest of the list
        // $mail->getSMTPInstance()->reset();
    // }
    // //Clear all addresses and attachments for the next iteration
    // $mail->clearAddresses();
    // $mail->clearAttachments();
	
	
	
	
// $mail = new PHPMailer(true);
// $mail->isSMTP();
// // ... SMTP configuration ...

// foreach ($recipients as $email => $name) {
    // $mail->addAddress($email, $name);
    // $mail->Subject = 'Subject';
    // $mail->Body = 'Body content';
    
    // if (!$mail->send()) {
        // echo "Error sending to $email";
    // }
    
    // // Reset for next recipient
    // $mail->clearAddresses();
    // $mail->clearAttachments();
// }
// Method 3: Single Email to Multiple Recipients To send the same email to multiple users without them seeing each other, add all addresses to one instance and use addBCC() or set
 // $mail->SingleTo = true to send individual SMTP transactions while keeping recipients private. 

// $mail = new PHPMailer();
// $mail->isSMTP();
// $mail->Host = 'smtp.example.com';
// $mail->setFrom('from@example.com', 'Sender Name');
// $mail->addAddress('to@example.com', 'Recipient Name'); // Wymagane
// $mail->addBCC('bcc1@example.com', 'Bcc Name 1');
// $mail->addBCC('bcc2@example.com', 'Bcc Name 2');
// $mail->Subject = 'Test';
// $mail->Body = 'Body';
// $mail->send();

$sth = null;
$dbh = null;