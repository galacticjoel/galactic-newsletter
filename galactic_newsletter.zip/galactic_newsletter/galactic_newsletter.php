<?php
	/*
		* Plugin Name: Galactic Newsletter
		* Description: Very simple newsletter plugin.
		* Plugin URI: https://meditation539.com/
		* Version: 1.0.0
		* Author: Galactic Joel
		* License: GPL-2.0-or-later
		* License URI: https://www.gnu.org/licenses/gpl-2.0.html
		* Text Domain: galactic_newsletter
	*/
	
	if( !defined('ABSPATH') ) {
		
		die('Nothin here');
		
	}
	
	
	define( 'GN_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
	require_once GN_PLUGIN_PATH.'inc/Widget.php';
	
	//define('WP', plugin_dir_path(__FILE__ ));
	
	
	//global $menu; print_r($menu);
	
	function galactic_newsletter_activate() {
		
		global $wpdb;
		
		// Define table name with WordPress prefix
		$ustawienia_smtp = $wpdb->prefix . 'gn_ustawienia_smtp';
		$newsletter_listy = $wpdb->prefix . 'newsletter_listy';
		$newsletter_subscribers = $wpdb->prefix . 'gn_subscribers';
		
		// Get charset and collation for the database
		$charset_collate = $wpdb->get_charset_collate();
		
		// Define the SQL statement for creating the table
		$sql_ustawienia_smtp = "CREATE TABLE IF NOT EXISTS $ustawienia_smtp (
        id int unsigned NOT NULL AUTO_INCREMENT,
		nazwa_nadawcy varchar(55) NOT NULL DEFAULT '',
        email_nadawcy varchar(55) NOT NULL DEFAULT '',
        reply_to varchar(55) NOT NULL DEFAULT '',
        serwer_smtp varchar(55) NOT NULL DEFAULT '',
		secure_smtp varchar(20) NOT NULL DEFAULT 'tls',
        port_smtp smallint unsigned NOT NULL DEFAULT 587,
		login varchar(55) NOT NULL DEFAULT '',
		password varchar(255) NOT NULL DEFAULT '',
		enc_tag varchar(32) NOT NULL DEFAULT '',
		enc_iv varchar(24) NOT NULL DEFAULT '',
		PRIMARY KEY  (id)
		
		) {$charset_collate};";
		
		$sql_newsletter_listy = "CREATE TABLE IF NOT EXISTS $newsletter_listy (
        id int unsigned NOT NULL AUTO_INCREMENT,
        nazwa_listy varchar(22) NOT NULL,
		kategoria varchar(22) NOT NULL,
        PRIMARY KEY  (id)
		
		) {$charset_collate};";
		
		$sql_subscribers = "CREATE TABLE IF NOT EXISTS $newsletter_subscribers (
		id bigint unsigned NOT NULL AUTO_INCREMENT,
		email varchar(254) NOT NULL,
		created_at datetime NOT NULL,
		confirmed tinyint(1) NOT NULL DEFAULT 0,
		confirmation_token char(64) DEFAULT NULL,
		unsubscribe_token char(64) DEFAULT NULL,
		token_expires_at datetime DEFAULT NULL,
		confirmed_at datetime DEFAULT NULL,
		PRIMARY KEY (id),
		UNIQUE KEY email (email)
		
		) {$charset_collate};";
		
		// Include dbDelta function
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		// Execute the query
		dbDelta( $sql_ustawienia_smtp );
		dbDelta( $sql_newsletter_listy );
		dbDelta( $sql_subscribers );
		
		flush_rewrite_rules();
		
	}
	
	
	function galactic_newsletter_deactivate() {
		
		flush_rewrite_rules();		
	}
	
	function galactic_newsletter_menu() {
		
		$file = plugin_dir_path(__FILE__) . 'templates/ustawienia.php';
		
		if (file_exists($file)) {
			require_once $file;
			} else {
			echo '<div class="notice notice-error"><p>Nie znaleziono pliku wtyczki.</p></div>';
		}
		
	}
	
	
	function galactic_newsletter_send_newsletter_submenu() {
		
		$file = plugin_dir_path(__FILE__) . 'templates/send_newsletter.php';
		
		if (file_exists($file)) {
			require_once $file;
			} else {
			echo '<div class="notice notice-error"><p>Nie znaleziono pliku wtyczki.</p></div>';
		}
		
	}
	
	function galactic_newsletter_test_email_submenu() {
		
		$file = plugin_dir_path(__FILE__) . 'templates/test_email.php';
		
		if (file_exists($file)) {
			require_once $file;
			} else {
			echo '<div class="notice notice-error"><p>Nie znaleziono pliku wtyczki.</p></div>';
		}
		
	}
	
	function galactic_newsletter_subscribers_submenu() {
		
		$file = plugin_dir_path(__FILE__) . 'templates/subscribers.php';
		
		if (file_exists($file)) {
			require_once $file;
			} else {
			echo '<div class="notice notice-error"><p>Nie znaleziono pliku wtyczki.</p></div>';
		}
		
	}
	
	function galactic_newsletter_add_admin_pages() {
		add_menu_page( 'Newsletter', 'Newsletter', 'manage_options', 'newsletter_plugin', 'galactic_newsletter_menu', 'dashicons-email', 110 );
		add_submenu_page( 'newsletter_plugin', 'send_newsletter', 'Wyślij Newsletter', 'manage_options', 'send_newsletter', 'galactic_newsletter_send_newsletter_submenu');
		add_submenu_page( 'newsletter_plugin', 'test_email', 'Test email', 'manage_options', 'test_email', 'galactic_newsletter_test_email_submenu');
		add_submenu_page( 'newsletter_plugin', 'subscribers', 'Subskrybenci', 'manage_options', 'subscribers', 'galactic_newsletter_subscribers_submenu');
		
	}
	
	
	function galactic_newsletter_settings_link( $links ) {
		$settings_link = '<a href="admin.php?page=newsletter_plugin">Ustawienia</a>';
		array_push( $links, $settings_link );
		return $links;
	}
	
	
	// register Galactic Newsletter widget
	function register_galactic_newsletter_widget() {
		register_widget( 'Galactic_Newsletter_Widget' );
	}
	
	
	//WP functions
	
	// activation
	register_activation_hook( __FILE__, 'galactic_newsletter_activate');
	
	// deactivation
	register_deactivation_hook( __FILE__, 'galactic_newsletter_deactivate');
	
	function galactic_newsletter_register() {
		
		$plugin = plugin_basename( __FILE__ );
		
		//add_action( 'admin_enqueue_scripts', 'enqueue');
		
		add_action('admin_menu', 'galactic_newsletter_add_admin_pages');
		
		add_filter( 'plugin_action_links_' . $plugin, 'galactic_newsletter_settings_link'); // dodaje link "Ustawienia" na liście wtyczek
		
		
	} 
	
	
	add_action( 'plugins_loaded', 'galactic_newsletter_register' );
	
	add_action( 'widgets_init', 'register_galactic_newsletter_widget' );
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
