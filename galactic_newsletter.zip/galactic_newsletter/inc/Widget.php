<?php
	
	use PHPMailer\PHPMailer\Exception;
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	
	// require_once GN_PLUGIN_PATH . 'PHPMailer/src/Exception.php';
	// require_once GN_PLUGIN_PATH . 'PHPMailer/src/PHPMailer.php';
	// require_once GN_PLUGIN_PATH . 'PHPMailer/src/SMTP.php';
	require_once GN_PLUGIN_PATH . 'inc/gn_functions.php';
	
		if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
		require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
		require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
		require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
	}
	
	
	class Galactic_Newsletter_Widget extends WP_Widget {
		
		private string $gn_status = '';
		private array  $errors = array();
		private string $email = '';
		private string $subscribers_table = '';
		
		private ?array $sub_result = null;
		
		private string $confirmation_token = '';
		private string $unsubscribe_token = '';
		private string $confirmation_token_hash = '';
		private string $unsubscribe_token_hash = '';
		private string $expires_at = '';
		 
		
		private $wpdb;
		
		public function __construct() {
			parent::__construct(
            'galactic_newsletter_widget',
            esc_html__('Galactic Newsletter', 'galactic_newsletter'),
            array( 'description' => esc_html__('Galactic Newsletter Widget', 'galactic_newsletter') )
			);
			
			global $wpdb;
			
			$this->wpdb = $wpdb;
			$this->subscribers_table = $this->wpdb->prefix . 'gn_subscribers';
			
			add_action('init', array($this, 'handle_subscription'));
		}
		
		public function handle_subscription(): void {
			if ( $_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['galactic_newsletter_submit']) ) {
				return;
			}
			
			$nonce_valid = $this->verify_subscription_nonce();
			
			if ($nonce_valid === false) {
				$this->gn_status = 'error';
				$this->errors['err_request'] = 'Nieprawidłowe żądanie formularza.';
				return;
			}
			
			$this->email = isset($_POST['sub_email']) ? sanitize_email(wp_unslash($_POST['sub_email'])) : '';
			
			if (!is_email($this->email)) {
				$this->gn_status = 'error';
				$this->errors['email'] = 'Podaj poprawny adres email.';
				return;
			}
			
			
			$this->sub_result = $this->get_subscriber_by_email($this->email);
			
			if ($this->sub_result !== null) {
				
				$confirmed = (int) $this->sub_result['confirmed'];
				
				if ($confirmed === 1) {
					$redirect_url = add_query_arg(
					'newsletter_error',
					'already_subscribed',
					wp_get_referer()
					);
					
					wp_safe_redirect($redirect_url);
					exit;
				}
				
				if ($confirmed === 0) {
					
					// generuj nowe tokeny
					$this->generate_tokens();
					
					// aktualizuj rekord
					$updated = $this->wpdb->update(
					$this->subscribers_table,
					array(
					'confirmation_token' => $this->confirmation_token_hash,
					'unsubscribe_token'  => $this->unsubscribe_token_hash,
					'token_expires_at'   => $this->expires_at,
					),
					array(
					'id' => (int) $this->sub_result['id'],
					),
					array(
					'%s',
					'%s',
					'%s',
					),
					array(
					'%d',
					)
					);
					
					if ($updated !== false) {
						
						$confirmation_url = $this->build_confirmation_url(
						(int) $this->sub_result['id']
						);
						
						$this->send_confirmation_email($this->email, $confirmation_url);
					}
					
					$redirect_url = add_query_arg(
					'newsletter_error',
					'confirmation_resent',
					wp_get_referer()
					);
					
					wp_safe_redirect($redirect_url);
					exit;
				}
			}
			
			$this->generate_tokens();
			
			$subscriber_id = $this->insert_subscriber();
			
			if ($subscriber_id === false) {
			    $this->errors['insert_sub_err'] = 'Nie udało się zapisać do bazy danych.';
				return;
			}
			
			$confirmation_url = $this->build_confirmation_url($subscriber_id);
			
			$email_sent = $this->send_confirmation_email($this->email, $confirmation_url);
			
			if ($email_sent === false) {
			 	return;
			}
			
			$this->gn_status = 'success';
			
			$this->redirect_after_success();
		}
		
		private function verify_subscription_nonce(): bool {
			if (!isset($_POST['galactic_newsletter_nonce'])) {
				return false;
			}
			
			$nonce = sanitize_text_field(wp_unslash($_POST['galactic_newsletter_nonce']));
			
			return wp_verify_nonce($nonce, 'galactic_newsletter_subscribe') !== false;
			
		}
		
		
		private function get_subscriber_by_email(string $email): ?array {
			$result = $this->wpdb->get_row( $this->wpdb->prepare("SELECT * FROM {$this->subscribers_table} WHERE email = %s LIMIT 1", $email),  ARRAY_A );
			
			if (!is_array($result)) {
				return null;
			}
			
			return $result;
		}
		
		private function generate_tokens(): void {
			$this->confirmation_token = bin2hex(random_bytes(32));;
			
			$this->unsubscribe_token = bin2hex(random_bytes(32));;
			
			$this->confirmation_token_hash = hash('sha256', $this->confirmation_token);
			
			$this->unsubscribe_token_hash = hash('sha256', $this->unsubscribe_token);
			
			// Token ważny przez 6 godzin.
			$this->expires_at = gmdate('Y-m-d H:i:s', time() + 6 * HOUR_IN_SECONDS);
		}
		
		private function build_confirmation_url(int $subscriber_id): string {
			return add_query_arg(
			array(
			'subscriber' => $subscriber_id,
			'token'      => $this->confirmation_token,
			),
			home_url('/aktywacja-subskrypcji')
			);
		}
		
		private function insert_subscriber(): int|false {
			$inserted = $this->wpdb->insert(
			$this->subscribers_table,
			array(
			'email'              => $this->email,
			'created_at'         => current_time('mysql'),
			'confirmed'          => 0,
			'confirmation_token' => $this->confirmation_token_hash,
			'unsubscribe_token'  => $this->unsubscribe_token_hash,
			'token_expires_at'   => $this->expires_at,
			),
			array(
			'%s', // email
			'%s', // created_at
			'%d', // confirmed
			'%s', // confirmation_token
			'%s', // unsubscribe_token
			'%s', // token_expires_at
			)
			);
			
			if ($inserted === false) {
				$this->gn_status = 'error';
				$this->errors['db_insert'] = 'Nie udało się zapisać subskrypcji.';
				
				error_log('Galactic Newsletter DB error: ' . $this->wpdb->last_error);
				
				return false;
			}
			
			return (int) $this->wpdb->insert_id;
		}
		
		
		
		private function get_smtp_settings(): ?array {
			$smtp_table = $this->wpdb->prefix . 'gn_ustawienia_smtp';
			
			$smtp_result = $this->wpdb->get_row(
			"SELECT
			nazwa_nadawcy,
			email_nadawcy,
			reply_to,
			serwer_smtp,
			secure_smtp,
			port_smtp,
			login,
			password,
			enc_tag,
			enc_iv
			FROM {$smtp_table}
			LIMIT 1",
			ARRAY_A
			);
			
			if (!is_array($smtp_result) || empty($smtp_result)) {
				$this->gn_status = 'error';
				$this->errors['send_error'] =
				'Nie udało się pobrać danych SMTP.';
				
				error_log(
				'Galactic Newsletter DB error: ' .
				$this->wpdb->last_error
				);
				
				return null;
			}
			
			return $smtp_result;
		}
		
		private function get_confirmation_email_body(
		string $confirmation_url
		): string {
			$safe_confirmation_url = esc_url($confirmation_url);
			
			return '
			<!DOCTYPE html>
			<html lang="pl">
			<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Potwierdzenie subskrypcji</title>
			</head>
			<body style="margin:0;padding:0;background-color:#dcdbda;font-family:Verdana,Helvetica,Arial,sans-serif;">
			<table style="width:100%;max-width:650px;margin:0 auto;background-color:#ffffff;">
			<tr>
			<td style="padding:40px 20px;text-align:center;">
			<h1 style="color:#04a404;">
			MEDYTACJA ~ potwierdzenie subskrypcji
			</h1>
			
			<p style="color:#572363;font-size:16px;line-height:1.6;font-weight:bold;">
			Dziękujemy za zapisanie się do newslettera.<br>
			Kliknij poniższy link,
			aby potwierdzić subskrypcję:<br>
			Link jest ważny przez 6 godzin.<br>
			<a href="' . esc_url($confirmation_url) . '" style="font-weight:normal;">
			Potwierdź subskrypcję</a><br></p>
			<p>
			lub wklej poniższy adres w przeglądarce:<br>' .
			$safe_confirmation_url .
			'</p>
			</td>
			</tr>
			</table>
			</body>
			</html>';
		}
		
		private function send_confirmation_email(string $email, string $confirmation_url): bool {
			$smtp = $this->get_smtp_settings();
			
			if ($smtp === null) {
				return false;
			}
			
			$decoded_password = galactic_newsletter_decrypt(
			$smtp['password'],
			$smtp['enc_iv'],
			$smtp['enc_tag']
			);
			
			if (!is_string($decoded_password) || $decoded_password === '') {
				$this->gn_status = 'error';
				$this->errors['confirm_email'] = 'Nie udało się odszyfrować hasła SMTP.';
				
				return false;
			}
			
			$mail = new PHPMailer(true);
			
			try {
				$mail->SMTPDebug = SMTP::DEBUG_OFF;
				$mail->isSMTP();
				$mail->Host = $smtp['serwer_smtp'];
				$mail->SMTPAuth = true;
				$mail->Username = $smtp['login'];
				$mail->Password = $decoded_password;
				switch ($smtp) {
					case 'ssl':
					$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
					break;
					
					case 'tls':
					case 'starttls':
					$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
					break;
					
					default:
					$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
				}
				
				$mail->Port       = $smtp['port_smtp'];  //465 TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
				
				$mail->CharSet = 'UTF-8';
				$mail->isHTML(true);
				
				$mail->setFrom($smtp['email_nadawcy'], $smtp['nazwa_nadawcy']);
				
				$mail->addReplyTo($smtp['reply_to'], $smtp['nazwa_nadawcy']);
				
				$mail->addAddress($email);
				
				$mail->Subject =
				'MEDYTACJA ~ potwierdzenie subskrypcji';
				
				$mail->Body = $this->get_confirmation_email_body(
				$confirmation_url
				);
				
				$mail->AltBody =
				'Potwierdź subskrypcję: ' . $confirmation_url;
				
				$sent = $mail->send();
				
				if ($sent === false) {
					$this->gn_status = 'error';
					$this->errors['confirm_email'] = 'Nie udało się wysłać emaila potwierdzającego.';
					
					return false;
				}
				
				return true;
				} catch (Exception $exception) {
				error_log(
				'Galactic Newsletter mail error: ' . $exception->getMessage());
				
				$this->gn_status = 'error';
				$this->errors['confirm_email'] = 'Błąd wysłania emaila potwierdzenia subskrypcji.';
				
				return false;
			}
		}
		
		private function redirect_after_success(): void {
			$redirect_url = wp_get_referer();
			
			if (!$redirect_url) {
				$redirect_url = home_url('/potwierdzenie-subskrypcji');
			}
			
			$redirect_url = add_query_arg('newsletter_subscribed', '1', $redirect_url);
			
			wp_safe_redirect($redirect_url);
			exit;
		}
		
		public function widget($args, $instance): void {
			echo $args['before_widget'];
			
			$error = isset($_GET['newsletter_error']) ? sanitize_key(wp_unslash($_GET['newsletter_error'])) : '';
			
			if ($error === 'already_subscribed') {
				echo '<div style="padding: 10px;margin-bottom: 15px;background: #fff3cd;border: 1px solid #ffe69c;color:#664d03">';
				echo '<p>Ten adres email jest już na naszej liście emailowej.</p>';
				echo '</div>';
			}
			
if ($error === 'confirmation_resent') {
    echo '<div style="padding:10px;margin-bottom:15px;background:#d1e7dd;border:1px solid #badbcc;color:#0f5132">';
    echo '<p>Wysłaliśmy nowy link potwierdzający na podany adres email.</p>';
    echo '</div>';
}
			
			if (!empty($instance['title'])) {
				echo $args['before_title'];
				
				echo esc_html(
				apply_filters(
				'widget_title',
				$instance['title']
				)
				);
				
				echo $args['after_title'];
			}
			
			$subscribed = isset($_GET['newsletter_subscribed'])
			? sanitize_key(wp_unslash($_GET['newsletter_subscribed']))
			: '';
			
			if ($subscribed === '1') {
				echo '<p class="newsletter-success">';
				echo esc_html__('Zostałeś zapisany do newslettera.', 'galactic_newsletter');
				echo '</p>';
			}
			
			if (!empty($this->errors)) {
				foreach ($this->errors as $error) {
				?>
				<div class="is-dismissible my_notice notice notice-error">
					<p><?php echo esc_html($error); ?></p>
				</div>
				<?php
				}
			}
		?>
		
		
		<form action="" method="post">
			
			<?php wp_nonce_field('galactic_newsletter_subscribe', 'galactic_newsletter_nonce'); ?>
			
			<p><label for="sub_email"><?php esc_html_e('Podaj swój email, aby otrzymywać powiadomienia o nowych wpisach:', 'galactic_newsletter'); ?></label></p>
			
			<input id="sub_email" name="sub_email" value="<?php echo esc_attr($this->email); ?>" type="email" maxlength="254" required style="width:92%;"><br>
			
			<button class="signup" name="galactic_newsletter_submit" type="submit" value="1" style="background-color:#4115a1;color:#fff;text-align:center;"><?php esc_html_e('Zapisz się', 'galactic_newsletter'); ?></button>
			
		</form>
		
		<?php
			echo $args['after_widget'];
		}
		
		public function form($instance): void {
			$title = !empty($instance['title'])
			? $instance['title']
			: esc_html__('Nowy tytuł', 'galactic_newsletter');
		?>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
				<?php esc_html_e('Tytuł:', 'galactic_newsletter'); ?>
			</label>
			
			<input id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>" class="widefat">
		</p>
		
		<?php
		}
		
		public function update($new_instance, $old_instance): array {
			$instance = array();
			
			$instance['title'] = !empty($new_instance['title'])
			? sanitize_text_field($new_instance['title'])
			: '';
			
			return $instance;
		}
	}
	
	
