<?php
	
	function galactic_newsletter_encrypt(string $plaintext):array {
		
		$key_smtp = SMTP_KEY;
		$key_bin_smtp = hex2bin($key_smtp);
		
		$iv_bin_smtp = random_bytes(12); // Zalecany rozmiar dla GCM
		$iv_hex_smtp = bin2hex($iv_bin_smtp);
		
		$plaintext_smtp = $plaintext;
		
		if (strlen($key_bin_smtp) !== 32) {
			throw new RuntimeException('SMTP encryption key must be 32 bytes.');
		}
		
		if (strlen($iv_bin_smtp) !== 12) {
			throw new RuntimeException('SMTP IV should be 12 bytes.');
		}
		
		// Szyfrowanie
		$encrypted_smtp_pswd = openssl_encrypt($plaintext_smtp, 'aes-256-gcm', $key_bin_smtp, 0, $iv_bin_smtp, $tag_smtp); //return Base64, params: key-bin, iv-bin, tag-bin
		
		$tag_smtp_hex = bin2hex($tag_smtp);
		
		if ($encrypted_smtp_pswd === false) {
			throw new RuntimeException('SMTP password encryption failed.');
		}
		
		$enc_data = array();
		$enc_data['enc_pswd'] = $encrypted_smtp_pswd;
		$enc_data['iv_hex'] = $iv_hex_smtp;
		$enc_data['tag_hex'] = $tag_smtp_hex;
		
		return $enc_data;
		
	}
	
	function galactic_newsletter_decrypt(string $enc_text, string $iv_hex, string $tag_hex):string {
		
		$key_smtp = SMTP_KEY;
		$key_bin_smtp = hex2bin($key_smtp);
		
		$encrypted_smtp = $enc_text;
		
		$iv_smtp = $iv_hex;
		$iv_bin_smtp = hex2bin($iv_smtp);
		
		$tag_bin_smtp = hex2bin($tag_hex);
		
		// Odszyfrowywanie
		
		$decrypted_smtp = openssl_decrypt($encrypted_smtp, 'aes-256-gcm', $key_bin_smtp, 0, $iv_bin_smtp, $tag_bin_smtp);
				
		if ($decrypted_smtp === false) {
			throw new RuntimeException(
			'SMTP password decryption failed or authentication validation failed.'
			);
		}
		
		
		return $decrypted_smtp;		
		
	}
	
	function galactic_newsletter_sanitize_text_field(?string $text){
		
		return sanitize_text_field(wp_unslash(trim($text)));
		
	}		 
	
	function galactic_newsletter_sanitize_email(?string $text){
		
		return sanitize_email(wp_unslash(trim($text)));
		
	}		 
	
	function galactic_newsletter_sanitize_tsanitize_textarea_field(?string $text){
		
		return sanitize_textarea_field(wp_unslash(trim($text)));
		
	}		 
	
	
	
	
	
	
?>