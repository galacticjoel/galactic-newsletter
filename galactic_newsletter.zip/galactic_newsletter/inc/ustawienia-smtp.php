<?php	
	declare(strict_types=1);
	
	require_once GN_PLUGIN_PATH.'inc/gn_functions.php';
	
	$status = '';
	$errors = array();
	
	
	if ( $_SERVER['REQUEST_METHOD'] === 'POST' &&  isset($_POST['wyslij']) ) { //if1
		
		if ( ! current_user_can( 'manage_options' ) ) {
			$status            = 'error';
			$errors['permission'] = 'Brak uprawnień.';
			
			} elseif ( !isset($_POST['smtp_nonce']) ||  !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['smtp_nonce'])),  'smtp_formularz') ) {
			
			$status = 'error';
			$errors['err_request'] = 'Nieprawidłowe żądanie formularza.';
			
			} else { // else1
			
			$nazwa_nadawcy = galactic_newsletter_sanitize_text_field($_POST['nazwa_nadawcy'] ?? '');
			$email_nadawcy = galactic_newsletter_sanitize_email($_POST['email_nadawcy'] ?? '');
			$reply_to = galactic_newsletter_sanitize_email($_POST['reply_to'] ?? '');
			$secure_smtp = sanitize_text_field($_POST['secure_smtp'] ?? '');
			$port_smtp   = absint($_POST['port_smtp'] ?? 587);
			$serwer = galactic_newsletter_sanitize_text_field($_POST['serwer'] ?? '');
			$login = galactic_newsletter_sanitize_email($_POST['smtp_login'] ?? '');
			$pswd = trim((string)($_POST['pswd'] ?? ''));
			
			
			if (empty($nazwa_nadawcy)) {
				
				$errors['name'] = 'Podaj imię lub nazwę.';
				
				} elseif (mb_strlen($nazwa_nadawcy) > 50) {
				
				$errors['name'] = 'Imię lub nazwa jest zbyt długa.';
			}
			
			if (empty($email_nadawcy)) {
				
				$errors['email'] = 'Podaj adres e-mail.';
				
				} elseif (!is_email($email_nadawcy)) {
				
				$errors['email_nadawcy'] = 'Podaj poprawny adres e-mail.';
				
				} elseif (mb_strlen($email_nadawcy) > 50) {
				
				$errors['email_nadawcy'] = 'Adres email jest zbyt długi.';
			}
			
			if (empty($reply_to)) {
				
				$errors['reply_to'] = 'Podaj adres e-mail.';
				
				} elseif (!is_email($reply_to)) {
				
				$errors['reply_to'] = 'Podaj poprawny adres e-mail.';
				
				} elseif (mb_strlen($reply_to) > 50) {
				
				$errors['reply_to'] = 'Adres email jest zbyt długi.';
			}
			
			if (empty($serwer)) {
				
				$errors['serwer'] = 'Podaj nazwę serwera.';
				
				} elseif (mb_strlen($serwer) > 50) {
				
				$errors['serwer'] = 'Nazwa serwera jest zbyt długa.';
			}
			
			if (empty($login)) {
				
				$errors['login'] = 'Podaj login.';
				
				} elseif (mb_strlen($login) > 50) {
				
				$errors['login'] = 'Nazwa loginu jest zbyt długa.';
			}
			
			if (empty($pswd)) {
				
				$errors['pswd'] = 'Podaj hasło';
				
				} elseif (mb_strlen($pswd) > 75) {
				
				$errors['pswd'] = 'Hasło jest zbyt długie.';
			}
			
			
			
			if (!empty($errors)) {
				
				$status = 'error';
				
				} else { // else2
				
				$enc_data = galactic_newsletter_encrypt($pswd);
				
				global $wpdb;
				$table_name = $wpdb->prefix . 'gn_ustawienia_smtp';
				
				$existing_id = $wpdb->get_var(
				"SELECT id FROM {$table_name} LIMIT 1"
				);
				
				$data = array(
				'nazwa_nadawcy' => $nazwa_nadawcy,
				'email_nadawcy' => $email_nadawcy,
				'reply_to'      => $reply_to,
				'serwer_smtp'   => $serwer,
				'secure_smtp'   => $secure_smtp,
				'port_smtp'     => $port_smtp,
				'login'         => $login,
				'password'      => $enc_data['enc_pswd'],
				'enc_tag'       => $enc_data['tag_hex'],
				'enc_iv'        => $enc_data['iv_hex']
				);
				
				$formats = array(
				'%s', // nazwa_nadawcy
				'%s', // email_nadawcy
				'%s', // reply_to
				'%s', // serwer_smtp
				'%s', // secure_smtp
				'%d', // port_smtp
				'%s', // login
				'%s', // password
				'%s', // enc_tag
				'%s'  // enc_iv
				);
				
				if ($existing_id) {
					
					$result = $wpdb->update(
					$table_name,
					$data,
					array('id' => $existing_id),
					$formats,
					array('%d')
					);
					
					} else {
					
					$result = $wpdb->insert(
					$table_name,
					$data,
					$formats
					);
				}
				
				if ($result === false) {
					$status = 'error';
					$errors['send_error'] = 'Nie udało się zapisać danych.';
					} else {
					$status = 'success';
				}
				
				
			} // koniec else2
			
		} // koniec else1
		
	} // koniec if1
	
	
	
	
	
	
