<?php
$available_ciphers = openssl_get_cipher_methods();
	// echo '<pre>';
	// print_r($available_ciphers);
	// echo '</pre>';
	
// $method = 'AES-256-GCM';  //AES-256-ECB, 
// $ivlen = openssl_cipher_iv_length($method); //16
// echo $ivlen."<br><br>";


$key_kp = openssl_random_pseudo_bytes(32); // return bin
$key_stc = openssl_random_pseudo_bytes(32);// 32 bajty = 256 bitów

$key_hex_kp = bin2hex($key_kp);
$key_hex_stc = bin2hex($key_stc);

echo "key_hex_KP: " .$key_hex_kp."<br><br>";
echo "key_hex_STC: " .$key_hex_stc."<br><br>";


$iv_kp = random_bytes(12); // Zalecany rozmiar dla GCM
$iv_stc = random_bytes(12);

$iv_kp_hex = bin2hex($iv_kp);
$iv_stc_hex = bin2hex($iv_stc);
 
echo "iv_hex_KP: " .$iv_kp_hex."<br><br>";
echo "iv_hex_STC: " .$iv_stc_hex."<br><br>";

$plaintext_kp = 'v7F<3+DwA^mx5Xj]Q3YS(B.oUN_6e)k2d9}2-8m;3zd:Ba';
$plaintext_stc = 'c_p7:sBD3FpW+VA4tViK{H<StL-5^FY>2,qux;XG]F3';


// Szyfrowanie
$encrypted_kp = openssl_encrypt($plaintext_kp, 'aes-256-gcm', $key_kp, 0, $iv_kp, $tag_kp); //return Base64, params: key-bin, iv-bin, tag-bin
$encrypted_stc = openssl_encrypt($plaintext_stc, 'aes-256-gcm', $key_stc, 0, $iv_stc, $tag_stc); //return Base64

echo "B64_encrypted_KP: " .$encrypted_kp."<br><br>";
echo "B64_encrypted_STC: " .$encrypted_stc."<br><br>";

$encodedTag_KP = bin2hex($tag_kp);
$decodedTag_KP = hex2bin($encodedTag_KP);

$encodedTag_STC = bin2hex($tag_stc);
$decodedTag_STC = hex2bin($encodedTag_STC);

echo "tag_KP_hex: " .$encodedTag_KP."<br><br>";
echo "tag_STC_hex: " .$encodedTag_STC."<br><br>";


// Odszyfrowywanie

$key_bin_kp = hex2bin($key_hex_kp);
$key_bin_stc = hex2bin($key_hex_stc);

$iv_kp_bin = hex2bin($iv_kp_hex);
$iv_stc_bin = hex2bin($iv_stc_hex);

$decrypted_kp = openssl_decrypt($encrypted_kp, 'aes-256-gcm', $key_bin_kp, 0, $iv_kp_bin, $decodedTag_KP);
echo "decrypted_KP: " .htmlspecialchars($decrypted_kp, ENT_QUOTES, 'UTF-8')."<br><br>";

$decrypted_stc = openssl_decrypt($encrypted_stc, 'aes-256-gcm', $key_bin_stc, 0, $iv_stc_bin, $decodedTag_STC);
echo "decrypted_STC: " .htmlspecialchars($decrypted_stc, ENT_QUOTES, 'UTF-8')."<br><br>";
 




?>