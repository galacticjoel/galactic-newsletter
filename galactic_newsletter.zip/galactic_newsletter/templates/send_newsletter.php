<?php
	
	if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	use PHPMailer\PHPMailer\SMTP;  
	
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/Exception.php';
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/PHPMailer.php';
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/SMTP.php';
	
	if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
		require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
		require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
		require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
	}
	
	//global $phpmailer;
	
	require_once GN_PLUGIN_PATH.'inc/gn_functions.php';
	
	$status = '';
	$errors = array();	
	$smtp_config_loaded = false;
	
	global $wpdb;
	$table_name = $wpdb->prefix . 'gn_ustawienia_smtp';
	$sql = "SELECT * FROM {$table_name}  LIMIT 1";
	
    $result = $wpdb->get_row($sql, ARRAY_A);
	
	if (!is_array($result)) {
		$status = 'error';
		
		if ($wpdb->last_error) {
			error_log('Galactic Newsletter DB error: ' . $wpdb->last_error);
			$errors['send_error'] = 'Nie udało się pobrać ustawień SMTP z bazy danych.';
			} else {
			$errors['send_error'] = 'Nie znaleziono ustawień SMTP. Zapisz je przed wysłaniem testowego emaila.';
		}
		
		} else {
		
		$nazwa_nadawcy = $result['nazwa_nadawcy'] ?? '';
		$email_nadawcy = $result['email_nadawcy'] ?? '';
		$reply_to      = $result['reply_to'] ?? '';
		$serwer_smtp   = $result['serwer_smtp'] ?? '';
		$secure_smtp   = $result['secure_smtp'] ?? 'tls';
		$port_smtp     = (int)($result['port_smtp'] ?? 587);
		$login_smtp    = $result['login'] ?? '';
		$enc_password  = $result['password'] ?? '';
		$enc_tag       = $result['enc_tag'] ?? '';
		$enc_iv        = $result['enc_iv'] ?? '';
		$dec_pswd      = galactic_newsletter_decrypt($enc_password, $enc_iv, $enc_tag);
		
		$smtp_config_loaded = true;
	}	
	
	
	if ( $smtp_config_loaded == true && $_SERVER['REQUEST_METHOD'] === 'POST' &&  isset($_POST['wyslij_newsletter']) ) { // if1
		
		if ( ! current_user_can( 'manage_options' ) ) {
			$status               = 'error';
			$errors['permission'] = 'Brak uprawnień.';
			
			} elseif ( !isset($_POST['smtp_send_newsletter_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash(trim($_POST['smtp_send_newsletter_nonce'] ?? ''))),'smtp_send_newsletter_formularz') ) {
			
			$status = 'error';
			$errors['err_request'] = 'Nieprawidłowe żądanie formularza.';
			
			} else { // else1
			
			$subs_table_name = $wpdb->prefix . 'gn_subscribers';
			$subscribers = $wpdb->get_results("SELECT id, email FROM {$subs_table_name} WHERE confirmed = 1", ARRAY_A);
			
			if (empty($subscribers)) {
				$status = 'error';
				$errors['send_error'] = 'Brak potwierdzonych subskrybentów.';
				
				} else {
				
				$liczba_postow = absint(wp_unslash($_POST['liczba_postów'] ?? 1));
				
				if ($liczba_postow < 1) {
					$liczba_postow = 1;
				}
				
				if ($liczba_postow > 12) {
					$liczba_postow = 12;
				}
				
				$ostatnie_posty = get_posts([
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => $liczba_postow,
				'orderby'        => 'date',
				'order'          => 'DESC'
				]);
				
				$posty_html = '';
				
				foreach ($ostatnie_posty as $post) {
					
					$tytul = esc_html($post->post_title);
					$link  = get_permalink($post->ID);
					
					$excerpt = esc_html(wp_strip_all_tags(get_the_excerpt($post)));
					
					$posty_html .= '
					<tr>
					<td style="padding:20px;">
					<h2>' . $tytul . '</h2>
					
					<p>' . esc_html($excerpt) . '</p>
					
					<p>
					<a href="' . esc_url($link) . '" style="margin-bottom:20px;">
					Czytaj dalej>>
					</a>
					</p>
					</td>
					</tr>';
				}
				
				//Create an instance; passing `true` enables exceptions
				$mail = new PHPMailer(true);
				$mail->CharSet = 'UTF-8';
				
				try { // try1
					
					//Server settings
					
					//Enable verbose debug output 0 (DEBUG_OFF): Wyłączenie debugowania (domyślne). 
					// 1 (DEBUG_CLIENT): Wyświetlanie tylko komend wysyłanych przez klienta.
					// 2 (DEBUG_SERVER): Wyświetlanie komend klienta oraz odpowiedzi serwera (najbardziej użyteczne). 
					// 3 (DEBUG_CONNECTION): Informacje o połączeniu plus poziom 2. 
					// 4 (DEBUG_LOWLEVEL): Bardzo szczegółowe informacje niskiego poziomu
					
					$mail->SMTPDebug = SMTP::DEBUG_OFF;
					$mail->Debugoutput = 'error_log';
					$mail->isSMTP();                                            //Send using SMTP
					$mail->Host       = $serwer_smtp;                     //Set the SMTP server to send through
					$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
					$mail->Username   = $login_smtp;                     //SMTP username
					$mail->Password   = $dec_pswd;                               //SMTP password
					switch ($secure_smtp) {
						case 'ssl':
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
						break;
						
						case 'tls':
						case 'starttls':
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
						break;
						
						default:
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
					}
					
					$mail->Port       = $port_smtp;  //465 TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
					
					
					$mail->isHTML(true);                                  //Set email format to HTML
					
					//Recipients
					$mail->setFrom($email_nadawcy, $nazwa_nadawcy);
					$reply_to = sanitize_email($reply_to);
					
					if ($reply_to !== '' && is_email($reply_to)) {
						$mail->addReplyTo($reply_to);
					}
					
					$mail->Subject = htmlspecialchars('MEDYTACJA ~ Newsletter', ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
					$mail->AltBody = htmlspecialchars('Newsletter', ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);		
					
					
					$failed = [];
					
					//set_time_limit(7200);
					foreach ($subscribers as $subscriber) {
						$unsubscribe_token = bin2hex(random_bytes(32));
						$unsubscribe_token_hash = hash('sha256', $unsubscribe_token);
						
						$updated = $wpdb->update($subs_table_name , array('unsubscribe_token' => $unsubscribe_token_hash), array('id' => (int) $subscriber['id']), array('%s'), array('%d'));
						
						if ($updated === false) {
							$failed[] = $subscriber['email'];
							continue;
						}
						
						$unsubscribe_url = add_query_arg(array('subscriber' => (int) $subscriber['id'], 'token' => $unsubscribe_token), home_url('/anulowanie-subskrypcji'));
						
						$email_body = '<!DOCTYPE html><html lang="en"; style="box-sizing: border-box">
						<head>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, initial-scale=1.0">
						<title>Newsletter</title>
						
						<style>
						
						tr{
						padding: 1px 15px
						}
						
						td{
						padding: 1px 15px
						}
						
						hr{
						width: 75%;
						margin-bottom: 15px;
						color: #411B4D 
						
						}
						
						
						/* Media query for screens wider than 600px */
						@media screen and (min-width: 600px) and (max-width:880px) {
						body {
						background-color: lightblue;
						}
						}
						</style>
						</head>
						<body style="margin: 0 auto; width: 100%; font-family: Verdana, Helvetica, Arial, sans-serif; background-color: #DCDBDA;">
						
						<table id="t1" style="width: 100%; max-width: 650px; background-color: #ffffff; cellpadding: 0;	cellspacing: 0; border: 0; 	margin: 0 auto;">
						<tbody><tr>
						<td>
						<table id="t2" style="width: 100%; max-width: 650px; cellpadding: 0;cellspacing: 0; border: 0;">
						<tbody><tr>
						<td style="padding: 10px; text-align: center">
						<a href="https://meditation539.com" target="_blank">
						<!--	<img src="https://meditation539.com/wp-content/uploads/2021/10/logo-1.jpg" alt="MEDYTACJA" width="150" height="50" decoding="async" style="max-width: 100%; height: auto">-->	
						<img src="C:/Users/galac/Pictures/logo/MEDYTACJA_CONSTANTIA4.jpg" alt="MEDYTACJA" width="250" height="85" decoding="async" style="max-width: 100%; height: auto">
						
						</a>
						</td>
						</tr>
						</tbody></table>
						</td>
						</tr>
						<tr>
						<td>
						<table id="t3" style="width: 100%;	max-width: 650px; cellpadding: 0; cellspacing: 0; border: 0; background-color: #f0f0f0">
						<tbody><tr>
						<td style="padding: 40px 20px; text-align: center">
						<h1 style="margin:0; line-height:1.25; margin-bottom:20px; font-size:28px; color:#04a404;">
						<p style="font-size: 16px; line-height: 1.6; color:#572363; font-weight: bold" >
						Nowy wpis od Cobry
						</p>
						</td>
						</tr>
						</tbody></table>
						</td>
						</tr>
						<tr>
						<td>
						
						<table width="100%" cellpadding="0" cellspacing="0">
						' . $posty_html . '
						</table></td></tr>
						<br> 
						<hr>
						
						<footer>
						<table id="t5" style="width: 100%;	max-width: 650px; cellpadding: 0; cellspacing: 0; border: 0; background-color: #E9FDE7;">
						<tr>
						<td	style="padding: 20px; text-align: center;">
						<p	style="margin: 0 0 10px 0;	line-height: 1.25;	font-size: 14px; color: #04a404;">
						@2026 MEDYTACJA
						</p>
						
						<a	href="' . esc_url($unsubscribe_url) . '" target="_blank"	style="display: block; 	width: 100%; box-sizing: border-box; line-height: 1.25;	font-size: 14px; color: #9C3B07; text-decoration: underline;">
						Anuluj subskrypcję
						</a>
						</td>
						</tr>
						</table>
						
						
						</footer>
						
						</tbody></table>
						
						</body></html>';
						
						$mail->clearAddresses();
						$mail->addAddress($subscriber['email']);
						$mail->Body = $email_body;
						
						try {
							$mail->send();
							set_time_limit(120);
							
							} catch (Exception $e) {
							$failed[] = $subscriber['email'];
							error_log('Nie udało się wysłać wiadomości do ' . sanitize_email($subscriber['email']) . ': ' . $mail->ErrorInfo);
							continue;
						}
						
						sleep(12);
					}
					
					
					if (empty($failed)) {
						$status = 'success';
						} else {
						$status = 'error';
						$errors['send_error'] = 'Nie udało się wysłać wiadomości do ' . count($failed) . ' adresów. Szczegóły zapisano w logu.';
					}
					
					} catch (Exception $e) {
					
					} catch (Exception $e) {
					$status = 'error';
					$errors['send_error'] = 'Wystąpił błąd podczas wysyłki newslettera. Szczegóły zapisano w logu.';
					
					error_log('Galactic Newsletter: ' . $e->getMessage());
					error_log('Galactic Newsletter DB error: ' . $wpdb->last_error);
				}			
		}
		
	} // koniec else1
} // koniec if1





?>


<style>
	
	label {
	font-family: Arial, sans-serif;
	font-size: 15px;
	font-weight: bold;
	color: #4F2361;
	}
	
	input {
	width: 300px;
	}
	
	input[type="submit"] {
	background-color: #5F21B0; /* background */
	color: white;              /* White text */
	border: solid;  
	border-width: 2px;
	border-color: white;
	padding: 10px 20px;         
	border-radius: 5px;        /* Rounded corners */
	cursor: pointer;           /* Pointer cursor on hover */
	font-size: 16px;
	}
	
	
	button {
	
	color: white;              /* White text */
	border: solid;  
	border-width: 2px;
	border-color: white;
	padding: 8px 14px; 
	margin: 8px 0;
	border-radius: 5px;        /* Rounded corners */
	cursor: pointer;           /* Pointer cursor on hover */
	background-color: #1A2E89;
	font-size: 16px;
	
	}
	
	button:hover {
	
	background-color: #7A178A; /* Darker blue on hover */
	
	}
	
	/* Media query for screens wider than 600px */
	@media screen and (min-width: 600px) and (max-width:880px) {
	body {
	background-color: lightblue;
	}
	}
	
</style>
<h1 style="padding: 20px; text-align: center; color: #ff8f00" >Wyślij Newsletter</h1>

<noscript><div class="my_notice notice notice-warning is-dismissible">
	<p>Your browser does not support JavaScript!</p>
</div><br><br></noscript>
<?php if ($status === 'success') : ?>
<div class="my_notice notice notice-success is-dismissible">
	<p>Newsletter został wysłany.</p>
</div><br>
<?php endif; ?>
<?php if ($status === 'error') : ?>
<?php foreach ($errors as $error) : ?> 
<div class="my_notice notice notice-error is-dismissible">
	<p><?php echo esc_html($error); ?></p>
</div><br>

<?php endforeach; ?>
<?php endif; ?>


<div id="newsletter-progress" style="display:none;" role="status" aria-live="polite">
    Newsletter jest w trakcie wysyłania.
</div>

<form id="newsletter-form" action="" method="post">
	
	<label for="liczba_postów">Wybierz liczbę postów do wysłania:</label>
	
	<select name="liczba_postów" id="liczba_postów">
		<?php	
			for ($i = 1; $i < 13; $i++):
			echo '<option value="'.$i.'">'.$i.'</option>';
			endfor;  
		?>
	</select><br><br>
	
	
	<?php wp_nonce_field('smtp_send_newsletter_formularz', 'smtp_send_newsletter_nonce'); ?> 
	<button type="submit" class="wyslij_newsletter" name="wyslij_newsletter" value="">Wyślij Newsletter</button><br>
	
</form><br> 

<script>
	document.addEventListener('DOMContentLoaded', function () {
		const form = document.getElementById('newsletter-form');
		const progress = document.getElementById('newsletter-progress');
		
		if (form && progress) {
			form.addEventListener('submit', function () {
				progress.style.display = 'block';
			});
		}
	});
</script>






