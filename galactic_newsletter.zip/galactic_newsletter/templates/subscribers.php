<?php
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}
	
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Nie masz uprawnień do wyświetlenia tej strony.', 'galactic_newsletter' ) );
	}
	
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'gn_subscribers';
	
	// Obsługa usuwania jednego adresu.
	if (  isset($_POST['gn_delete_subscriber'], $_POST['subscriber_id'], $_POST['_wpnonce']) ) {
		$subscriber_id = absint( wp_unslash( $_POST['subscriber_id'] ) );
		
		if (!current_user_can( 'manage_options' ) || ! wp_verify_nonce(sanitize_text_field( wp_unslash($_POST['_wpnonce']) ), 'gn_delete_subscriber_' . $subscriber_id ) ) {
			wp_die( esc_html__( 'Nieprawidłowe żądanie.', 'galactic_newsletter' ) );
		}
		
		$deleted = $wpdb->delete(
        $table_name,
        array( 'id' => $subscriber_id ),
        array( '%d' )
		);
		
		if ( false === $deleted ) {
			echo '<div class="notice notice-error"><p>'
            . esc_html__( 'Nie udało się usunąć subskrybenta.', 'galactic_newsletter' )
            . '</p></div>';
			} else {
			// Przekierowanie zapobiega ponownemu wysłaniu formularza po odświeżeniu.
			wp_safe_redirect( admin_url( 'admin.php?page=subscribers&deleted=1' ) );
			exit;
		}
	}
	
	// Akceptuj tylko znane wartości filtra.
	$status = isset( $_GET['subs'] ) ? sanitize_key( wp_unslash( $_GET['subs'] ) ) : 'all';
	
	if ( ! in_array( $status, array( 'all', 'confirmed', 'unconfirmed' ), true ) ) {
		$status = 'all';
	}
	
	$sql = "SELECT id, email, created_at, confirmed, confirmed_at
	FROM {$table_name}";
	
	if ( 'confirmed' === $status ) {
		$sql .= ' WHERE confirmed = %d';
		$subscribers = $wpdb->get_results($wpdb->prepare( $sql . ' ORDER BY created_at DESC', 1), OBJECT );
		} elseif ( 'unconfirmed' === $status ) {
		$sql .= ' WHERE confirmed = %d';
		$subscribers = $wpdb->get_results($wpdb->prepare( $sql . ' ORDER BY created_at DESC', 0), OBJECT );
		} else {
		$subscribers = $wpdb->get_results( $sql . ' ORDER BY created_at DESC' );
	}
	
	if ( $wpdb->last_error ) {
		echo '<div class="notice notice-error"><p>'
        . esc_html__( 'Nie udało się pobrać subskrybentów.', 'galactic_newsletter' )
        . '</p></div>';
		return;
	}
	
	if ( isset( $_GET['deleted'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['deleted'] ) ) ) {
		echo '<div class="notice notice-success is-dismissible"><p>'
        . esc_html__( 'Subskrybent został usunięty.', 'galactic_newsletter' )
        . '</p></div>';
	}
	
	
	
	
?>

<style>
	
	.wrap label {
	font-family: Arial, sans-serif;
	font-size: 15px;
	font-weight: bold;
	color: #4F2361;
	}
	
	#gn_delete_subscriber {
	 background-color: #DB3C24;
	}
	
	.wrap h1 {
	padding: 20px; 
	text-align: center; 
	color: #308016;
	font-weight: 600;
	font-size: 25px;	
	}
	
	#gn-delete-modal{
	border-width: medium;
    border-style: solid;
    border-color: #0E7005;
	
	}
	
</style>



<div class="wrap">
    <h1><?php echo esc_html__( 'Subskrybenci newslettera', 'galactic_newsletter' ); ?></h1>
	
	<form method="get">
		<input type="hidden" name="page" value="subscribers">
		
		<label for="subs">Wybierz subskrybentów wg statusu: </label>
		<select name="subs" id="subs">
			<option value="all" <?php selected( $status, 'all' ); ?>>Wszyscy</option>
			<option value="confirmed" <?php selected( $status, 'confirmed' ); ?>>Potwierdzeni</option>
			<option value="unconfirmed" <?php selected( $status, 'unconfirmed' ); ?>>Niepotwierdzeni</option>
		</select>
		
		<button type="submit" class="button">Filtruj</button>
	</form>
	<br>
	
	
    <?php if ( empty( $subscribers ) ) : ?>
	<p><?php echo esc_html__( 'Brak zapisanych adresów.', 'galactic_newsletter' ); ?></p>
    <?php else : ?>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php echo esc_html__( 'Adres e-mail', 'galactic_newsletter' ); ?></th>
				<th><?php echo esc_html__( 'Data zapisu', 'galactic_newsletter' ); ?></th>
				<th><?php echo esc_html__( 'Status', 'galactic_newsletter' ); ?></th>
				<th><?php echo esc_html__( 'Data potwierdzenia', 'galactic_newsletter' ); ?></th>
				<th>Akcje</th>
				
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $subscribers as $subscriber ) : ?>
			<tr>
				<td><?php echo esc_html( $subscriber->email ); ?></td>
				<td><?php echo esc_html( $subscriber->created_at ); ?></td>
				<td>
					<?php
						echo $subscriber->confirmed
						? esc_html__( 'Potwierdzony', 'galactic_newsletter' )
						: esc_html__( 'Niepotwierdzony', 'galactic_newsletter' );
					?>
				</td>
				<td>
					<?php
						echo $subscriber->confirmed_at ? esc_html( $subscriber->confirmed_at ) : : esc_html__('Brak', 'galactic_newsletter');
					?>
				</td>
				<td>
					<button type="button" class="button button-link-delete gn-open-delete-modal" data-id="<?php echo esc_attr( $subscriber->id ); ?>" data-email="<?php echo esc_attr( $subscriber->email ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'gn_delete_subscriber_' . absint( $subscriber->id ) ) ); ?>">Usuń</button>
				</td>				
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<dialog id="gn-delete-modal" aria-labelledby="gn-delete-title">
		<h2 id="gn-delete-title" style="font-size: 19px;">Potwierdź usunięcie</h2>
		
		<p style="font-size: 17px;">
			Czy na pewno chcesz usunąć subskrybenta
			<strong id="gn-delete-email"></strong>?
		</p>
		
		<form method="post" id="gn-delete-form">
			<input type="hidden" name="subscriber_id" id="gn-delete-id">
			<input type="hidden" name="_wpnonce" id="gn-delete-nonce">
			
			<button type="button" class="button" id="gn-cancel-delete" style="margin-right: 7px;">
				Anuluj
			</button>
			
			<button type="submit" id="gn_delete_subscriber" name="gn_delete_subscriber" class="button button-primary">
				Usuń subskrybenta
			</button>
		</form>
	</dialog>
	
	<?php endif; ?>
	
	
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('gn-delete-modal');

    if (!modal) {
        return;
    }

    const emailLabel = document.getElementById('gn-delete-email');
    const idInput = document.getElementById('gn-delete-id');
    const nonceInput = document.getElementById('gn-delete-nonce');
    const cancelButton = document.getElementById('gn-cancel-delete');

    document.querySelectorAll('.gn-open-delete-modal').forEach(function (button) {
        button.addEventListener('click', function () {
            idInput.value = button.dataset.id;
            nonceInput.value = button.dataset.nonce;
            emailLabel.textContent = button.dataset.email;
            modal.showModal();
        });
    });

    cancelButton.addEventListener('click', function () {
        modal.close();
    });
});
</script>

