<?php
	
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	use PHPMailer\PHPMailer\SMTP;  
	
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/Exception.php';
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/PHPMailer.php';
	// require_once GN_PLUGIN_PATH.'PHPMailer/src/SMTP.php';
	
	if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
		require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
		require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
		require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
	}
	
	require_once GN_PLUGIN_PATH.'inc/gn_functions.php';
	
	$status = '';
	$errors = array();	
	$smtp_config_loaded = false;
	
	global $wpdb;
	$table_name = $wpdb->prefix . 'gn_ustawienia_smtp';
	$sql = "SELECT * FROM {$table_name}  LIMIT 1";
	
    $result = $wpdb->get_row($sql, ARRAY_A);
	
	if (!is_array($result)) {
		$status = 'error';
		
		if ($wpdb->last_error) {
			error_log('Galactic Newsletter DB error: ' . $wpdb->last_error);
			$errors['send_error'] = 'Nie udało się pobrać ustawień SMTP z bazy danych.';
			} else {
			$errors['send_error'] = 'Nie znaleziono ustawień SMTP. Zapisz je przed wysłaniem testowego emaila.';
		}
		
		} else {
		
		$nazwa_nadawcy = $result['nazwa_nadawcy'] ?? '';
		$email_nadawcy = $result['email_nadawcy'] ?? '';
		$reply_to      = $result['reply_to'] ?? '';
		$serwer_smtp   = $result['serwer_smtp'] ?? '';
		$secure_smtp = $result['secure_smtp'] ?? 'tls';
		$port_smtp   = (int)($result['port_smtp'] ?? 587);
		$login_smtp    = $result['login'] ?? '';
		$enc_password  = $result['password'] ?? '';
		$enc_tag       = $result['enc_tag'] ?? '';
		$enc_iv        = $result['enc_iv'] ?? '';
		$dec_pswd      = galactic_newsletter_decrypt($enc_password, $enc_iv, $enc_tag);
		
		$smtp_config_loaded = true;
	}
	
	
	// echo '<pre>';
	// print_r($result);
	// echo '<pre>';
	
	
	
	if ( $smtp_config_loaded = true && $_SERVER['REQUEST_METHOD'] === 'POST' &&  isset($_POST['wyslij_test']) ) { // if1
		
		if ( ! current_user_can( 'manage_options' ) ) {
			$status            = 'error';
			$errors['permission'] = 'Brak uprawnień.';
			
			} elseif ( !isset($_POST['smtp_test_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash(trim($_POST['smtp_test_nonce'] ?? ''))),'smtp_test_formularz') ) {
			
			$status = 'error';
			$errors['err_request'] = 'Nieprawidłowe żądanie formularza.';
			
			} else { // else1
			
			$test_email = sanitize_email(wp_unslash(trim($_POST['adres_odbiorcy'] ?? '')));
			
			if (empty($test_email)) {
				
				$errors['email'] = 'Podaj adres e-mail.';
				
				} elseif (!is_email($test_email)) {
				
				$errors['email'] = 'Podaj poprawny adres e-mail.';
				
				} elseif (mb_strlen($test_email) > 50) {
				
				$errors['email'] = 'Adres email jest zbyt długi.';
			}
			
			if (!empty($errors)) {
				
				$status = 'error';
				
				} else { // else2
				
				
				//Create an instance; passing `true` enables exceptions
				$mail = new PHPMailer(true);
				$mail->CharSet = 'UTF-8';
				
				try { // try1
					
					//Server settings
					
					//Enable verbose debug output 0 (DEBUG_OFF): Wyłączenie debugowania (domyślne). 
					// 1 (DEBUG_CLIENT): Wyświetlanie tylko komend wysyłanych przez klienta.
					// 2 (DEBUG_SERVER): Wyświetlanie komend klienta oraz odpowiedzi serwera (najbardziej użyteczne). 
					// 3 (DEBUG_CONNECTION): Informacje o połączeniu plus poziom 2. 
					// 4 (DEBUG_LOWLEVEL): Bardzo szczegółowe informacje niskiego poziomu
					
					$mail->SMTPDebug = SMTP::DEBUG_OFF;
					$mail->Debugoutput = 'error_log';
					$mail->isSMTP();                                            //Send using SMTP
					$mail->Host       = $serwer_smtp;                     //Set the SMTP server to send through
					$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
					$mail->Username   = $login_smtp;                     //SMTP username
					$mail->Password   = $dec_pswd;                               //SMTP password
					switch ($secure_smtp) {
						case 'ssl':
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
						break;
						
						case 'tls':
						case 'starttls':
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
						break;
						
						default:
						$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
					}
					$mail->Port       = $port_smtp;  //465 TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
					
					
					$mail->isHTML(true);                                  //Set email format to HTML
					
					$email_body = '<!DOCTYPE html><html lang="en"; style="box-sizing: border-box">
					<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
					<title>Email testowy</title>	
					<style>
					
					tr{
					padding: 1px 15px
					}
					
					td{
					padding: 1px 15px
					}
					
					hr{
					width: 75%;
					margin-bottom: 15px;
					color: #411B4D 
					
					}
					
					
					/* Media query for screens wider than 600px */
					@media screen and (min-width: 600px) and (max-width:880px) {
					body {
					background-color: lightblue;
					}
					}
					</style>
					</head>
					<body style="margin: 0 auto; width: 100%; font-family: Verdana, Helvetica, Arial, sans-serif; background-color: white;">
					
					<table cellpadding="0" cellspacing="0" id="t1" style="width: 100%; max-width: 650px; background-color: #ffffff; border: 0; 	margin: 0 auto;">
					<tbody><tr>
					<td>
					<table cellpadding="0" cellspacing="0" id="t2" style="width: 100%; max-width: 650px; border: 0;">
					<tbody><tr>
					<td style="padding: 10px; text-align: center">
					<a href="https://meditation539.com" target="_blank">
					<img src="https://meditation539.com/wp-content/uploads/2021/10/logo-1.jpg" alt="MEDYTACJA" width="250" height="85" decoding="async" style="max-width: 100%; height: auto"></a>
					</td>
					</tr>
					</tbody></table>
					</td>
					</tr>
					<tr>
					<td>
					<table cellpadding="0" cellspacing="0" id="t3" style="margin-bottom: 15px; width: 100%;	max-width: 650px; border: 0; background-color: #f0f0f0">
					<tbody><tr>
					<td style="padding: 40px 20px; text-align: center">
					<h1 style="
					margin: 0;
					line-height: 1.25;
					margin-bottom: 20px;
					font-size: 28px;
					color: #04a404;
					">
					MEDYTACJA ~ email testowy
					</h1>
					<p style="font-size: 16px; line-height: 1.6; color:#572363; font-weight: bold" >
					To jest testowy email!!!
					</p>
					</td>
					</tr>
					</tbody></table>
					
					
					<hr>
					
					<footer>
					<table cellpadding="0" cellspacing="0" id="t5" style="width: 100%;	max-width: 650px; border: 0; background-color: #E9FDE7;">
					<tr>
					<td	style="padding: 20px; text-align: center;">
					<p	style="margin: 0 0 10px 0;	line-height: 1.25;	font-size: 14px; color: #04a404;">
					@2026 MEDYTACJA
					</p>
					
					</td>
					</tr>
					</table>
					
					
					</footer>
					
					</tbody></table>
					
					
					</body></html>';
					
					//Recipients
					$mail->setFrom($email_nadawcy, $nazwa_nadawcy);
					$mail->addReplyTo($reply_to);
					$mail->addAddress($test_email);
					$mail->Subject = htmlspecialchars('MEDYTACJA ~ email testowy', ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);
					$mail->Body    =  $email_body;
					$mail->AltBody = htmlspecialchars('email testowy', ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401);		
					
					
					//Send Email
					set_time_limit(30);
					$mail->send();
					$status = 'success';
					
					
					// koniec try1
					} catch (Exception $e) {
					error_log('Galactic Newsletter DB error: ' . $wpdb->last_error);
					error_log('Galactic Newsletter DB error: ' . $e->getMessage());
					$status  = 'error';
					$errors['test_email'] = 'Błąd wysłania testowego emaila.';
				}		
				
				
			} // koniec else2
			
		} // koniec else1
	} // koniec if1
	
	
	
	
	
	$admin_email = get_option('admin_email');   	
	
	
?>


<style>
	
	label {
	font-family: Arial, sans-serif;
	font-size: 15px;
	font-weight: bold;
	color: #4F2361;
	}
	
	input {
	width: 300px;
	}
	
	input[type="submit"] {
	background-color: #5F21B0; /* background */
	color: white;              /* White text */
	border: solid;  
	border-width: 2px;
	border-color: white;
	padding: 10px 20px;         
	border-radius: 5px;        /* Rounded corners */
	cursor: pointer;           /* Pointer cursor on hover */
	font-size: 16px;
	}
	
	
	button {
	
	color: white;              /* White text */
	border: solid;  
	border-width: 2px;
	border-color: white;
	padding: 8px 14px; 
	margin: 8px 0;
	border-radius: 5px;        /* Rounded corners */
	cursor: pointer;           /* Pointer cursor on hover */
	background-color: #1A2E89;
	font-size: 16px;
	
	}
	
	button:hover {
	
	background-color: #7A178A; /* Darker blue on hover */
	
	}
	
	/* Media query for screens wider than 600px */
	@media screen and (min-width: 600px) and (max-width:880px) {
	body {
	background-color: lightblue;
	}
	}
	
</style>
<h1 style="padding: 20px; text-align: center; color: #ff8f00" >Przetestuj SMTP</h1>

<noscript><div class="my_notice notice notice-warning is-dismissible">
	<p>Your browser does not support JavaScript!</p>
</div><br><br></noscript>
<?php if ($status === 'success') : ?>
<div class="my_notice notice notice-success is-dismissible">
	<p>Email został poprawnie wysłany.</p>
</div><br>
<?php endif; ?>
<?php if ($status === 'error') : ?>
<?php foreach ($errors as $error) : ?> 
<div class="my_notice notice notice-error is-dismissible">
	<p><?php echo esc_html($error); ?></p>
</div><br>

<?php endforeach; ?>
<?php endif; ?>



<form action="" method="post">
	
	<b><label for="adres_nadawcy">Adres odbiorcy:</label></b><br><br> 
	<input type="email" id="adres_odbiorcy" name="adres_odbiorcy" value="<?php echo esc_attr($admin_email)?>" maxlength="50" required autofocus><br><br>
	<?php wp_nonce_field('smtp_test_formularz', 'smtp_test_nonce'); ?> 
	<button type="submit" class="wyslij_test" name="wyslij_test" value="wyślij">Wyślij</button><br>
	
</form><br> 







