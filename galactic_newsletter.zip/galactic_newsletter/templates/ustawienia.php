<?php
	
	
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}
	require_once GN_PLUGIN_PATH.'inc/ustawienia-smtp.php';	
?>

<h1 style="padding: 20px; text-align: center; color: #308016" >Ustawienia SMTP</h1>
<style>
	
	label {
	font-family: Arial, sans-serif;
	font-size: 15px;
	font-weight: bold;
	color: #4F2361;
	}
	
	input {
	width: 300px;
	}
	
	select {
	width: 150px;
	}
	
	button {
	background-color: #5F21B0; /* background */
	color: white;              /* White text */
	border: solid;  
	border-width: 2px;
	border-color: white;
	padding: 7px 20px;         
	border-radius: 5px;        /* Rounded corners */
	cursor: pointer;           /* Pointer cursor on hover */
	font-size: 16px;
	}
	
	button:hover {
	background-color: #7A178A; /* Darker blue on hover */
	}
	
	.info {
	
	font-size: 12px;
	margin-bottom: 15px;
	color: #401754;
	
	}
	
	.my_notice {
	font-family: Arial, sans-serif;
	font-size: 15px;
	font-weight: bold;
	margin-top: 25px;
	}
	
	/* Media query for screens wider than 600px */
	@media screen and (min-width: 600px) and (max-width:880px) {
	body {
	background-color: lightblue;
	}
	}
	
</style>

<noscript><div class="my_notice notice notice-warning is-dismissible">
	<p>Your browser does not support JavaScript!</p>
</div><br><br></noscript>		
<?php if ($status === 'success') : ?>
<div class="my_notice notice notice-success is-dismissible">
	<p>Dane zostały poprawnie zapisane.</p>
</div><br><br>
<?php endif; ?>

<?php if ($status === 'error') : ?>
<?php foreach ($errors as $error) : ?> 
<div class="my_notice notice notice-error is-dismissible">
	<p><?php echo esc_html($error); ?></p>
</div><br>

<?php endforeach; ?>
<?php endif; ?>

<form action="" method="post">
	<b><label for="nazwa_nadawcy">Nazwa nadawcy:</label></b><br> 
	<input type="text" id="nazwa_nadawcy" name="nazwa_nadawcy" value="<?php echo esc_attr($_POST['nazwa_nadawcy'] ?? '');?>" maxlength="50" required autofocus><br><br>
	<b><label for="email_nadawcy">Adres nadawcy:</label></b><br> 
	<input type="email" id="email_nadawcy" name="email_nadawcy" value="<?php echo esc_attr($_POST['email_nadawcy'] ?? '');?>" maxlength="50" required><br><br>
	<b><label for="reply_to">Reply to:</label></b><br> 
	<input type="email" id="reply_to" name="reply_to" value="<?php echo esc_attr($_POST['reply_to'] ?? '');?>" maxlength="50" required><br><br>
	<b><label for="serwer">Serwer smtp:</label></b><br> 
	<input type="text" id="serwer" name="serwer" value="<?php echo esc_attr($_POST['serwer'] ?? '');?>" maxlength="50" required><br><br>
	<b><label for="secure_smtp">Secure smtp:</label></b><br> 
	<select name="secure_smtp" id="secure_smtp">
		<option value="ssl">SSL</option>
		<option value="tls">TLS</option>
		<option value="starttls" selected>STARTTLS</option>
	</select><br><br>
	<b><label for="port_smtp">Port smtp:</label></b><br> 
	<input type="text" id="port_smtp" name="port_smtp" value="<?php echo esc_attr($_POST['port_smtp'] ?? '');?>"  min="1"
    max="65535" required><br><br>
	<b><label for="smtp_login">Login:</label></b><br> 
	<input type="text" id="login" name="smtp_login" value="<?php echo esc_attr($_POST['smtp_login'] ?? '');?>" maxlength="50" required><br><br>
	<b><label for="pswd">Hasło:</label></b><br> 
	<input type="password" id="pswd" name="pswd" value="" size="5" maxlength="75" required><br> 
	<div class="info">Maksymalna liczba znaków 75</div>
	<?php wp_nonce_field('smtp_formularz', 'smtp_nonce'); ?> 
	<button type="submit" class="wyslij" name="wyslij" value="wyslij">Wyślij</button><br>
	
</form>   </b><br> 







